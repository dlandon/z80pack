
void makeRasterFont(void);
void printString(char *s);
void printStringAt(char *s,float xpos,float ypos);


