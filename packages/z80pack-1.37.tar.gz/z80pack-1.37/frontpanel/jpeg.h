// jpeg.h

#ifndef __JPEG_DEFS__
#define __JPEG_DEFS__ 

unsigned char 
*read_jpeg(char *fname, int *width, int *height, int *num_components);

#endif
